package com.apps.gkakadiy.tripa.data;

public class Reactions {
    private String reation_id;
    private String reaction_context;
    private String context_id;
    private String reaction;
    private String start_date;
    private String user_id;
    private String last_updated_date;

    public String getReation_id() {
        return reation_id;
    }

    public void setReation_id(String reation_id) {
        this.reation_id = reation_id;
    }

    public String getReaction_context() {
        return reaction_context;
    }

    public void setReaction_context(String reaction_context) {
        this.reaction_context = reaction_context;
    }

    public String getContext_id() {
        return context_id;
    }

    public void setContext_id(String context_id) {
        this.context_id = context_id;
    }

    public String getReaction() {
        return reaction;
    }

    public void setReaction(String reaction) {
        this.reaction = reaction;
    }

    public String getStart_date() {
        return start_date;
    }

    public void setStart_date(String start_date) {
        this.start_date = start_date;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getLast_updated_date() {
        return last_updated_date;
    }

    public void setLast_updated_date(String last_updated_date) {
        this.last_updated_date = last_updated_date;
    }
}
