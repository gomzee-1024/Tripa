package com.apps.gkakadiy.tripa.data;

public class FCMToken {
    private String fcm_token;

    public String getFcm_token() {
        return fcm_token;
    }

    public void setFcm_token(String fcm_token) {
        this.fcm_token = fcm_token;
    }
}
