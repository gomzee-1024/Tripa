package com.apps.gkakadiy.tripa.data;

public enum LoginType {
    EMAIL ,
    GOOGLE ,
    FACEBOOK ,
    TWITTER
}
