package com.apps.gkakadiy.tripa.data;

public enum RequestType {
    TRIP_REQUEST,
    FRIEND_REQUEST;
}
