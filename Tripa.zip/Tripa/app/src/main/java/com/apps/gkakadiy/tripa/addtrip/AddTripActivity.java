package com.apps.gkakadiy.tripa.addtrip;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import com.apps.gkakadiy.tripa.R;

public class AddTripActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_trip);
    }
}
