package com.apps.gkakadiy.tripa.data;

public enum TripShareType {
    FRIENDS,
    PUBLIC,
    PRIVATE;
}
