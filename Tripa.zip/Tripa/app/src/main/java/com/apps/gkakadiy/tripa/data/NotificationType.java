package com.apps.gkakadiy.tripa.data;

public enum NotificationType {
    FRIEND_REQUEST,
    FRIEND_REQUEST_STATUS,
    TRIP_REQUEST,
    TRIP_REQUEST_STATUS,
    LIKE,
    COMMENT;
}
