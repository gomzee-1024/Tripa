package com.apps.gkakadiy.tripa.data;

public enum ProgressDialogType {
    POSITIVE_BUTTON,
    NEGATIVE_BUTTON,
    BOTH_BUTTON,
    NO_BUTTON;
}
