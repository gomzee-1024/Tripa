package com.apps.gkakadiy.tripa.data;

public class Comments {
    private String comment_id;
    private String comment_context;
    private String context_id;
    private String comment_reation_count1;
    private String comment_reation_count2;
    private String comment_reation_count3;
    private String comment_reation_count4;
    private String parent_id;
    private String user_id;
    private String start_date;
    private String last_updated_date;
    private String text;

    public String getComment_reation_count1() {
        return comment_reation_count1;
    }

    public void setComment_reation_count1(String comment_reation_count1) {
        this.comment_reation_count1 = comment_reation_count1;
    }

    public String getComment_reation_count2() {
        return comment_reation_count2;
    }

    public void setComment_reation_count2(String comment_reation_count2) {
        this.comment_reation_count2 = comment_reation_count2;
    }

    public String getComment_reation_count3() {
        return comment_reation_count3;
    }

    public void setComment_reation_count3(String comment_reation_count3) {
        this.comment_reation_count3 = comment_reation_count3;
    }

    public String getComment_reation_count4() {
        return comment_reation_count4;
    }

    public void setComment_reation_count4(String comment_reation_count4) {
        this.comment_reation_count4 = comment_reation_count4;
    }

    public String getComment_id() {
        return comment_id;
    }

    public void setComment_id(String comment_id) {
        this.comment_id = comment_id;
    }

    public String getComment_context() {
        return comment_context;
    }

    public void setComment_context(String comment_context) {
        this.comment_context = comment_context;
    }

    public String getContext_id() {
        return context_id;
    }

    public void setContext_id(String context_id) {
        this.context_id = context_id;
    }

    public String getParent_id() {
        return parent_id;
    }

    public void setParent_id(String parent_id) {
        this.parent_id = parent_id;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getStart_date() {
        return start_date;
    }

    public void setStart_date(String start_date) {
        this.start_date = start_date;
    }

    public String getLast_updated_date() {
        return last_updated_date;
    }

    public void setLast_updated_date(String last_updated_date) {
        this.last_updated_date = last_updated_date;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
