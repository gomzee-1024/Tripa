package com.apps.gkakadiy.tripa.data;

public enum FriendRequestStatus {
    SENT,
    ACCEPTED,
    REJECTED;
}
