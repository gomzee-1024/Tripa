package com.apps.gkakadiy.tripa.data;

public enum FriendStatusType {
    NOT_FRIENDS,
    REQUESTED,
    FRIENDS;
}
