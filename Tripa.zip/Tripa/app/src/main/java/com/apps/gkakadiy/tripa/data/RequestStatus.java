package com.apps.gkakadiy.tripa.data;

public enum RequestStatus {
    ACCEPTED,
    REJECTED,
    JOINED,
    REQUESTED;
}
